const express = require("express");
const mongoose = require("mongoose");

const User = require("../../../models/signupmodel");
const reviewsoncoursemodel = require("../../../models/Reviews/reviewsoncourse");
const reviewsoninstitutemodel = require("../../../models/Reviews/reviewsoninstitute");
const CourseModel = require('../../../models/Course/course')

// Getting all Reviews ( role:institute is deafult)
// const getReviews = async (req, resp) => {
//   reviewsmodel.find()
//     .then((result) => {
//       resp.status(200).json({
//         Reviews: result,
//       });
//     })
//     .catch((err) => {
//       resp.status(500).json({
//         Error: err,
//       });
//     });
// };

// Posting Reviews
const postReviewOnCourse = (req, resp) => {
  User.findOne({ _id: req.params.id }).then((val) => {
    const { name, desc, rating, ref_id, course_id } = req.body;

    const postReviewOnCourse = new reviewsoncoursemodel({
      _id: new mongoose.Types.ObjectId(),
      name: val.name,
      desc,
      rating,
      ref_id: req.params.id,
      course_id
    })
      .save()

      .then((result) => {
        console.log(result);
        resp.status(200).json(result);
      })

      .catch((err) => {
        console.log(err);
        resp.status(500).json({ error: err });
      });
  });
};

// Getting All Reviews of  Course 
const ReviewOnCourse = (req, resp) => {
    reviewsoncoursemodel.find({ course_id: req.params.id })

    .then((result) => {
      CourseModel.find({ _id: req.params.id })
      .then(val2 => {resp.status(200).json(result)})
      .catch((err) => {
        resp.status(500).json({ error: err })
      })
    })
    .catch((err) => {
      resp.status(500).json({ error: err })
    });
};

// Getting all reviews of Course
const getAllReviewsOnCourse = (req, resp) => {
  reviewsoncoursemodel
    .find()
    .exec()
    .then((result) => {
      resp.status(200).json(result);
    })
    .catch((error) => {
      resp.status(500).json({ err });
    });
};

////////////////////////////////////////////////

const postReviewOnInstitute = (req, resp) => {
  User.findOne({ _id: req.params.id }).then((val) => {
    const { name, desc, rating, ref_id, institute_id } = req.body;

    const postReviewOnInstitute = new reviewsoninstitutemodel({
      _id: new mongoose.Types.ObjectId(),
      name: val.name,
      desc,
      rating,
      ref_id: req.params.id,
      institute_id
    })
      .save()

      .then((result) => {
        console.log(result);
        resp.status(200).json(result);
      })

      .catch((err) => {
        console.log(err);
        resp.status(500).json({ error: err });
      });
  });
};

const ReviewOnInstitute = (req, resp) => {
  reviewsoninstitutemodel
    .find({ institute_id: req.params.id })

    .then((result) => {
      User.find({ _id: req.params.id })
      .then(val2 => {resp.status(200).json(result)})
      // {name: val2[0].name , "no_of_comments" : result.length}
      .catch((err) => {
        resp.status(500).json({ error: err })
      })
    })
    .catch((err) => {
      resp.status(500).json({ error: err })
    });
};

// Getting all reviews of Institute
const getAllReviewsOnInstitute = (req, resp) => {
  reviewsoninstitutemodel
    .find()
    .exec()
    .then((result) => {
      resp.status(200).json(result);
    })
    .catch((error) => {
      resp.status(500).json({ err });
    });
};


//////////////////////////////////////////////////////


// If admin wants to delete Institute the  he just pass his id as params
const deleteReview = (req, resp) => {
  reviewsmodel
    .findById({ _id: req.params.id })
    .deleteMany()
    .then((result) => {
      resp.status(200).json(result);
    })
    .catch((err) => {
      resp.status(500).json(err)
});
};


const ReviewByStudent = async (req, resp) => {
  const ref_id =  req.params.id ;
try {
  const response = await reviewsoncoursemodel.find({ref_id})
  const response2 = await reviewsoninstitutemodel.find({ref_id})
  resp.status(200).json([...response , ...response2])
} catch (error) {
  resp.status(500).json(error)
}
};

module.exports = { getAllReviewsOnCourse , getAllReviewsOnInstitute, deleteReview, ReviewOnInstitute , ReviewOnCourse , ReviewByStudent ,postReviewOnCourse , postReviewOnInstitute };
